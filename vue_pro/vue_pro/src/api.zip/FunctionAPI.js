import {CreatePost} from "./PostAPI.js";

export function showPassword(){
    if(document.getElementById('Password').type === "text"){
        document.getElementById('Password').type = "password";
    }else{
        document.getElementById('Password').type = "text";
    }
}


export function onFileChange(event, post) {     //选择图片
    post.Photo = event.target.files[0].name
}

export function onSubmit() {        //提交新建帖子
    CreatePost(this.formData)
        .then(response => {
            console.log(response.data);
        })
        .catch(error => {
            console.log(error);
        });
}

