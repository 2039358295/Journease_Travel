import axios from "axios";


export function AddLike(PostID, CommentID){         //评论点赞
    return axios({
        method:'put',
        url:'/community/Like',
        data:JSON.stringify({
            PostID:PostID,
            CommentID: CommentID,
        })
    })
}

export function CancelLike(PostID, CommentID){          //取消评论点赞
    return axios({
        method:'put',
        url:'/community/Dislike',
        data:JSON.stringify({
            PostID:PostID,
            CommentID: CommentID,
        })
    })
}

export function DislikePost(postid){
    return axios.put("/community/DislikePost",JSON.stringify({
            PostID: parseInt(postid)
        })
    )
        .then(response =>{
            if(response.data.code===200){
                alert("取消喜欢成功！")
            }else {
                alert("取消喜欢失败！")
            }
        })
}

export function LikePost(postid){
    return axios.put("/community/LikePost",JSON.stringify({
            PostID: parseInt(postid)
        })
    )
        .then(response =>{
            if(response.data.code===200){
                alert("喜欢成功！")
            }else {
                alert("喜欢失败！")
            }
        })
}